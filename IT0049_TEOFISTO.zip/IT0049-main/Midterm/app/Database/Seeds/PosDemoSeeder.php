<?php
namespace App\Database\Seeds;
use CodeIgniter\Database\Seeder;
class PosDemoSeeder extends Seeder {
 public function run(){$items=[['Canvas Tote',12.50],['Desk Notebook',6.75],['Wireless Mouse',18.00],['USB-C Cable',9.25],['Travel Mug',14.50],['Phone Stand',11.00],['Screen Cleaner',5.50],['Key Organizer',8.25]];foreach($items as [$name,$price])if(!$this->db->table('products')->where('name',$name)->countAllResults())$this->db->table('products')->insert(['name'=>$name,'price'=>$price,'stock_quantity'=>35,'is_active'=>1,'created_at'=>date('Y-m-d H:i:s')]);}
}
